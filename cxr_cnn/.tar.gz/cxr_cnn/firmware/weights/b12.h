//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
bias12_t b12[8];
#else
bias12_t b12[8] = {-0.860273122787, 1.417840123177, 0.656738579273, -1.966237902641, 0.456822127104, -0.937843084335, 0.173751413822, 1.090397596359};
#endif

#endif

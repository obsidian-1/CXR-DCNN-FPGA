//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B18_H_
#define B18_H_

#ifndef __SYNTHESIS__
bias18_t b18[8];
#else
bias18_t b18[8] = {0.774454474449, -0.593512415886, 1.610934734344, 1.863246679306, 1.780130386353, 0.612948358059, -0.214712113142, -0.920836925507};
#endif

#endif

//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
bias7_t b7[8];
#else
bias7_t b7[8] = {0.678096175194, -0.813167512417, -0.478273570538, 0.618132591248, -0.202210515738, -1.178800106049, 0.399850368500, 0.748307168484};
#endif

#endif

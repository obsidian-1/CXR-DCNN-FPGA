//Numpy array shape [3]
//Min -0.079516738653
//Max 0.103915661573
//Number of zeros 0

#ifndef B26_H_
#define B26_H_

#ifndef __SYNTHESIS__
output_dense_default_t b26[3];
#else
output_dense_default_t b26[3] = {-0.079516738653, -0.031715232879, 0.103915661573};
#endif

#endif
